//
//  MveHealthkit.h
//  mvehealthkit
//
//  Created by Your Name
//  Copyright (c) 2020 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MveHealthkit.
FOUNDATION_EXPORT double MveHealthkitVersionNumber;

//! Project version string for MveHealthkit.
FOUNDATION_EXPORT const unsigned char MveHealthkitVersionString[];

#import "MveHealthkitModuleAssets.h"
